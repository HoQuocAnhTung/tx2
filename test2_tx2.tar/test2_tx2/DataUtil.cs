﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.IO;

namespace test2_tx2
{
    internal class DataUtil
    {
        XmlElement root;
        XmlDocument doc;
        string path;

        public DataUtil()
        {
            path = "../../bangdiem.xml";
            doc = new XmlDocument();
            if (!File.Exists(path))
            {
                XmlElement tv = doc.CreateElement("bangdiem");
                doc.AppendChild(tv);
                doc.Save(path);
            }
            doc.Load(path);
            root = doc.DocumentElement;
        }
        public List<sinhvien> getAllData()
        {
            XmlNodeList lst_node_data = root.SelectNodes("sinhvien");
            List<sinhvien> sinhvien_list = new List<sinhvien>();
            foreach (XmlNode node in lst_node_data)
            {
                sinhvien sv = new sinhvien();
                sv.masv = node.Attributes["masv"].Value;
                sv.hoten = node.SelectSingleNode("hoten").InnerText;
                sv.monhoc = node.Attributes["monhoc"].Value;
                sv.diemlan1 = int.Parse(node.SelectSingleNode("diemlan1").InnerText);
                sv.diemlan2 = int.Parse(node.SelectSingleNode("diemlan2").InnerText);
                sinhvien_list.Add(sv);
            }
            return sinhvien_list;
        }
        public bool them_sv(sinhvien s)
        {
            XmlNode sinhvienmoi = root.SelectSingleNode($"sinhvien[@masv = '{s.masv}' ]");
            if(sinhvienmoi != null)
            {
                return false;
            }
            XmlElement sinhvien = doc.CreateElement("sinhvien");
            XmlElement hoten = doc.CreateElement("hoten");
            XmlElement diemlan1 = doc.CreateElement("diemlan1");
            XmlElement diemlan2 = doc.CreateElement("diemlan2");
            sinhvien.SetAttribute("masv", s.masv);
            sinhvien.SetAttribute("monhoc", s.monhoc);
            hoten.InnerText = s.hoten;
            diemlan1.InnerText = s.diemlan1.ToString();
            diemlan2.InnerText = s.diemlan2.ToString();
            sinhvien.AppendChild(hoten);
            sinhvien.AppendChild(diemlan2 );
            sinhvien.AppendChild(diemlan1);
            root.AppendChild(sinhvien);
            doc.Save(path);
            return true;

        }
        public bool sua_sv(sinhvien s)
        {
            XmlNode sinhvienmoi = root.SelectSingleNode($"sinhvien[@masv = '{s.masv}' ]");
            if (sinhvienmoi == null)
            {
                return false;
            }
            XmlElement sinhvien_new = doc.CreateElement("sinhvien");
            XmlElement hoten = doc.CreateElement("hoten");
            XmlElement diemlan1 = doc.CreateElement("diemlan1");
            XmlElement diemlan2 = doc.CreateElement("diemlan2");
            sinhvien_new.SetAttribute("masv", s.masv);
            sinhvien_new.SetAttribute("monhoc", s.monhoc);
            hoten.InnerText = s.hoten;
            diemlan1.InnerText = s.diemlan1.ToString();
            diemlan2.InnerText = s.diemlan2.ToString();
            sinhvien_new.AppendChild(hoten);
            sinhvien_new.AppendChild(diemlan2);
            sinhvien_new.AppendChild(diemlan1);
            root.ReplaceChild(sinhvien_new, sinhvienmoi);
            doc.Save(path);
            return true;
        }

        public bool xoa_sv(string id)
        {
            XmlNode sinhvienmoi = root.SelectSingleNode($"sinhvien[@masv = '{id}' ]");
            if (sinhvienmoi == null)
            {
                return false;
            }

            root.RemoveChild(sinhvienmoi);
            doc.Save(path);
            return true;
        }
    }
}
