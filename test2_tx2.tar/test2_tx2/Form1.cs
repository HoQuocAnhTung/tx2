﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test2_tx2
{
    public partial class btn_sua : Form
    {
        public btn_sua()
        {
            InitializeComponent();
        }
        DataUtil data= new DataUtil();
        private void DisplayData()
        {
            List<sinhvien> lst_data = data.getAllData();
            dgvData.DataSource = lst_data;
            dgvData.Columns[0].Width = 50;
            dgvData.Columns[1].Width = 150;
            dgvData.Columns[2].Width = 150;
            dgvData.Columns[3].Width = 50;
            dgvData.Columns[4].Width = 50;
            dgvData.Columns[0].HeaderText = "STT";
            dgvData.Columns[1].HeaderText = "Họ tên SV";
            dgvData.Columns[2].HeaderText = "Môn học";
            dgvData.Columns[3].HeaderText = "Điểm lần 1";
            dgvData.Columns[4].HeaderText = "Điểm lần 2";
            dgvData.ReadOnly = true;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            // Cách 1: Thêm trực tiếp
            cbmmonhoc.Items.Add("Lập trình Java");
            cbmmonhoc.Items.Add("Lập trình Windows");
            cbmmonhoc.Items.Add("Cơ sở dữ liệu");

            // Hoặc (Cách 2: Thêm một lần bằng AddRange)
            // cboMonHoc.Items.AddRange(new string[] { "Lập trình Java", "Lập trình Windows", "Cơ sở dữ liệu" });

            cbmmonhoc.SelectedIndex = 0; // Chọn phần tử đầu tiên để hiển thị luôn
            DisplayData();
        }

        private void btn_them_Click(object sender, EventArgs e)
        {
            try
            {
                sinhvien sv = new sinhvien();
                sv.masv = txtmasv.Text;
                sv.hoten = txthoten.Text;
                sv.monhoc= cbmmonhoc.Text;
                sv.diemlan1 = int.Parse(txtdiem1.Text);
                sv.diemlan2 = int.Parse(txtdiem2.Text);
                if (data.them_sv(sv))
                {
                    MessageBox.Show("Đã thêm thành công , Thông báo");
                    DisplayData();
                }
                else
                {
                    MessageBox.Show("Chưa thành công ");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void CeilClick(object sender, DataGridViewCellEventArgs e)
        {
            sinhvien chose = (sinhvien)dgvData.CurrentRow.DataBoundItem;
            txtmasv.Text = chose.masv;
            txthoten.Text = chose.hoten;
            cbmmonhoc.Text=chose.monhoc;
            txtdiem1.Text = chose.diemlan1.ToString();
            txtdiem2.Text = chose.diemlan2.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                sinhvien sv = new sinhvien();
                sv.masv = txtmasv.Text;
                sv.hoten = txthoten.Text;
                sv.monhoc = cbmmonhoc.Text;
                sv.diemlan1 = int.Parse(txtdiem1.Text);
                sv.diemlan2 = int.Parse(txtdiem2.Text);
                if (data.sua_sv(sv))
                {
                    MessageBox.Show("Đã thêm thành công , Thông báo");
                    DisplayData();
                }
                else
                {
                    MessageBox.Show("Chưa thành công ");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string ma_xoa = txtmasv.Text;
                DialogResult d = MessageBox.Show("Ban Có muốn xóa không ? ", "Thông Báo",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (d == DialogResult.Yes)
                {
                    if (data.xoa_sv(ma_xoa))
                    {
                        MessageBox.Show("Xoas thành công , Thông báo");
                        DisplayData();
                    }
                    else
                    {
                        MessageBox.Show("Không thành cồng");
                    }
                }
            }
            catch(Exception ex) 
            {
                    MessageBox.Show(ex.Message);
            }
            
        }
    }
}
