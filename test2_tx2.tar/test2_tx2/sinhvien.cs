﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test2_tx2
{
    internal class sinhvien
    {
        public string masv {  get; set; }
        public string hoten {get; set; }
        public string monhoc { get; set; }
        public int diemlan1 { get; set; }
        public int diemlan2 { get; set; }
    }
}
